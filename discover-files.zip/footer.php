
        <div class="row">
            <div class="col-lg-2 col-lg-offset-5">
                <hr class="marginbot-50">
            </div>
        </div>

		<div class="container">
	    <div class="row col-lg-6">
    <div class="row col-lg-12" >
        <h5>Subscribe to Our NewsLetter</h5>
        </div>
      
    <div class="row col-lg-8 col-md-12 col-sm-12 col-xs-12 " >
         <div class="input-group">
        
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" /></div>
                        
        </div>
<div class="row col-lg-2 col-md-12 col-sm-12 col-xs-12">
  &nbsp;
</div>
    <div class="row col-lg-2 col-md-12 col-sm-12 col-xs-12"  >
                            <div class="pull-left">
            
                        <button type="submit" class="btn btn-skin " id="btnContactUs" >
                            Subscribe</button>
                    </div></div>

 </div>
	   <div class="row col-lg-2 ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>


    	<div class="row col-lg-4 ">
			<div class="widget-contact">
	
                <address>
                  <h5>We're on social networks</h5>
                        <ul class="company-social">
                            <li class="social-facebook"><a href="http://facebook.com/PropChunk" target="_blank"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-twitter"><a href="http://twitter.com/PropChunk" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        </ul>   
                </address>                  
           

			</div>	
		</div>
 <div class="row col-lg-12">
&nbsp;
 </div>         
<div class="row col-lg-2 col-md-3 col-sm-4 col-xs-12">
    <address class="text-left;">
                  <h5 id="text-left1">Company</h5>
                      <ul class="list-group text-left">
                            <li class="list-group-item le text-left" id="le" ><a href="#" target="_blank">About</a></li>
                                                 </ul>   
                </address>                  

 </div>


        
<div class=" row col-lg-2 col-md-3 col-sm-4 col-xs-12">
    <address class="text-left;">
                  <h5 id="text-left1">Invest</h5>
                        <ul class="list-group le text-left" >
                            <li class="list-group-item le text-left" id="le"><a href="#" target="_blank">Browse Project</a></li>
                            <li class="list-group-item le text-left" id="le"><a href="#" target="_blank">Investor Protection</a></li>
                             
                                                 </ul>   
                </address>                  

 </div>

<div class="row col-lg-2 col-md-3 col-sm-4 col-xs-12">
    <address class="text-left;">
                  <h5 id="text-left1">Learn</h5>
                        <ul class="list-group le text-left">
                            <li class="list-group-item le text-left" id="le"><a href="#" target="_blank">How it works</a></li>
                            <li class="list-group-item le text-left" id="le"><a href="#" target="_blank">FAQ's</a></li>
                             <li class="list-group-item le text-left" id="le"><a href="#" target="_blank">Blog</a></li>
                                                 </ul>   
                </address>                  

 </div>

       <div class="row col-lg-2 ">
&nbsp;    </div>

    <div class="row col-lg-4 col-md-3 col-sm-4 col-xs-12">
            <div class="widget-contact">
       
               <h5>Main Office</h5>
                <address>
                  D/9, Ansa Estate,<br>
                  Opp. Kotak Bank & Vodafone Gallery,<br>
                  Saki Naka, Andheri (E), Mumbai.<br>
                  <abbr>P:</abbr> +91 9699 796629

             
                    </address>

                <address>
                  <strong>Email</strong><br>
                  <a href="mailto:#"> hello@propchunk.com</a>
                </address>  
                <address>

                <address>
                  <strong>2016. All Rights Reserved.<br />
    
    Chunk Technologies Pvt. Ltd.</strong>
                 
                </address>      
  </div>        
    </div>
    </div>	
		 
        </div>




	</section>
	<!-- /Section: contact -->

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
	<!-- PROGRESS BAR-->
    <script src="progress-bar-js.js"></script>

