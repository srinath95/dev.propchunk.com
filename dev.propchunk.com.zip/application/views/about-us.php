
    <section id="about" class="home-section text-center">
		<div class="heading-about">
			<div class="container">
				<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow bounceInDown" data-wow-delay="0.4s">
					<div class="section-heading">
					<h2>About Us</h2>
					<i class="fa fa-2x fa-angle-down"></i>

					</div>
					</div>
				</div>
			</div>
			</div>
		</div>
		<div class="container">

		<div class="row">
			<div class="col-lg-2 col-lg-offset-5">
				<hr class="marginbot-50">
			</div>
		</div>

	
		<h2 align="center" >Propchunk Story</h2>
		<br/>
		<div class="inner">
		<ol class="dropDown" style="list-style:none;">
		
			<li>
		<div class=" row col-xs-12 col-sm-12 col-md-12">
				
		<p>
		Indians love property, and it is a great asset to invest in. But investing in real estate typically requires huge amounts of money, locking out most investors. We have setup the financial structures using a Special Purpose Vehicle (SPV) based model in which many small investors come together to contribute small amounts towards a specific project development. This SPV, which will most likely be a partnership firm, will have all investors as its partners.	

Pooled money is then passed to the Project Developer and each investor ends up owning a piece of the pie. Investors are investing in a registered SPV on the back of strong legal documentation held by Chunk Technologies Pvt. Ltd.

	</p>
</div>
</li>
</ol>
</div>




    <section id="about" class="home-section text-center">
		<div class="heading-about">
			<div class="container">
				<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow bounceInDown" data-wow-delay="0.4s">
					<div class="section-heading">
					<h2>Meet the team</h2>
					<i class="fa fa-2x fa-angle-down"></i>

					</div>
					</div>
				</div>
			</div>
			</div>
		</div>
		<div class="container">

		<div class="row">
			<div class="col-lg-2 col-lg-offset-5">
				<hr class="marginbot-50">
			</div>
		</div>

<div class="row" >
	
	<div class="row col-xs-12 col-sm-12 col-md-2">
	</div>
            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="wow bounceInUp" data-wow-delay="0.2s">
                <div class="team boxed">
                    <div class="inner">
                        <div class="avatar"><img src="<?php echo base_url('/images/kamal2.jpg');?>" alt="" class="img-responsive img-circle" /></div>
                    
						<h5>Kamal Laungani</h5>
                        <p class="subtitle">Co-Founder</p>
                    </div>
                </div>
				</div>
            </div>
			<div class="col-xs-12 col-sm-6 col-md-4">
				<div class="wow bounceInUp" data-wow-delay="0.5s">
                <div class="team boxed">
                    <div class="inner">
                        <div class="avatar"><img src="<?php echo base_url('/images/rajeev2.jpg');?>" alt="" class="img-responsive img-circle"  /></div>
                        
						<h5>Rajeev Kumar</h5>
                        <p class="subtitle">Co-Founder</p>
                    </div>
                </div>
				</div>
            </div>

</div>
</div></div></div>






    <section id="about" class="home-section text-center">
		<div class="heading-about">
			<div class="container">
				<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow bounceInDown" data-wow-delay="0.4s">
					<div class="section-heading">
					<h2>Want to Start CrowdFunding your RealEstate?</h2>
					<i class="fa fa-2x fa-angle-down"></i>

					</div>
					</div>
				</div>
			</div>
			</div>
		</div>
		<div class="container">

		<div class="row"> 
			<div class="col-lg-2 col-lg-offset-5">
				<hr class="marginbot-50">
			</div>
		</div>

<div class="col-xs-12 col-sm-12 col-md-12">
			
<h3><i>You don&#39;t become rich by saving, you become rich by investing.</i> With our curated deals in growing geographies, you can be a property owner too.</h3>
<div class="col-xs-12 col-sm-12 col-md-12">
			
		                        <button type="submit" class="btn btn-skin " id="btnContactUs" href="https://propchunk.youcanbook.me/?skipHeaderFooter=true" style="padding:20px;margin-right:5px;">
                            Discover</button>
                           <button type="submit" class="btn btn-skin " id="btnContactUs" href="faq.html" style="padding:20px;">
                            Learn More</button>
</ul>
</div>
</section>
