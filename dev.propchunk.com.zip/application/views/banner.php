
<section id="banner">
<div class="inner">
<h2 style="font-size: 190%;">PROP CHUNK</h2>

<p>OWN A PIECE OF MUMBAI<br />
FOR AS LITTLE AS <span style="white-space:pre;"><b><i class="fa fa-inr"></i> 1 LAKH *</b></span><br />
<pre><i><a href="https://twitter.com/hashtag/FractionalOwnership" style="text-transform: none;" target="_blank">#FractionalOwnership</a> </i></pre></p>
&nbsp;

<section>
<form action="#" method="post">
<div class="row uniform" style="display: flex;flex-direction: row;flex-wrap: wrap;justify-content: center;align-items: center;"><!-- <div class="10u$ 9u$(small) 12u$(xsmall)">Register for the private beta launch</div> <br/> --><!-- <div class="4u$ 6u$(medium) 10u$(small) 12u$(xsmall)">
												<input type="text" name="demo-email" id="demo-email" value="" placeholder="Email Address" />
											</div> --><!--<div class="12u$">
												<ul class="actions">
													<li><a href="#openModal" class="button fit special">Sign Up for Official Launch</a></li>
														<div id="openModal" class="modalDialog">
															<div>
																<a href="#close" title="Close" class="close">X</a>
																<iframe id="my_typeform" src="https://propchunk.typeform.com/to/VL6Pxs"></iframe>
															</div>
														</div>
												</ul>
											</div> -->
<div class="12u$">
<ul class="actions">
	<li><!-- <input type="submit" value="Send Message" class="special"> --><a class="button fit special typeform-share button" data-mode="1" href="https://propchunk.typeform.com/to/VL6Pxs" target="_blank">Sign Up in 30 seconds</a> <script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'share.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}id=id+'_';if(!gi.call(d,id)){qs=ce.call(d,'link');qs.rel='stylesheet';qs.id=id;qs.href=b+'main.css';s=gt.call(d,'head')[0];s.appendChild(qs,s)}})()</script>

	<p>Get exclusive Launch access.</p>
	</li>
</ul>
</div>
</div>
</form>
</section>
</div>
<a class="more scrolly" href="#one">Learn More</a></section>
