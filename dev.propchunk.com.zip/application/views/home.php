<!DOCTYPE HTML>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>#FractionalOwnership of Real Estate in India</title>
	<meta content="IE=edge" http-equiv="X-UA-Compatible" /><!-- Open Graphic -->
	<meta content="PropChunk Crowd-Investing. Fractional Ownership of Real Estate" property="og:title" />
	<meta content="Invest in Mumbai Real Estate Developments from Rs. 1 Lakh. View listing now. " property="og:description" />
	<meta content="http://www.propchunk.com/images/banner.jpg" property="og:image" />
	<meta content="PropChunk" property="og:site_name" />
	<meta content="http://www.propchunk.com" property="og:url" />
	<meta content="website" property="og:type" /><!-- META DATA -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport" />
	<meta content="Invest in Mumbai Real Estate Developments from Rs. 1 Lakh. View listing now." name="description" /><!-- SEO Keywords -->
	<meta content="Mumbai Real Estate, Property Investment, Prop Chunk, Fractional Ownership, Fractional Ownership of properties, Fractional Ownership of real estate, Crowd Funding, crowdfunding, crowd investing, cheap flats mumbai, cheap property india, affordable housing, small ticket size, buy house mumbai, high appreciation, where to invest, mumbai real estate invest, best places to invest in property, palghar property, boisar property, virar property, vasai property, real estate crowdfunding, real estate crowdfunding India, 
real estate crowdfunding india,
india real estate crowdfunding,
Fractional Ownership India,
India Fractional Ownership,
propchunk crowdinvesting,
propchunk crowdinvestment,
propchunk crowdinvestments,
propchunk fractional ownership
propchunk fractional investment
propchunk fractional property investment
propchunk fractal investment,
fractal investment india,
fractal investment
wishberry,
crowd funding,
ketto,
chunk prop,
cafes mumbai,
kickstarter india,
mogul,
REIT,
property shares,
shares,
propertyshare,
www.propertyshare.in,
property share,
fractional ownership bangalore,
propertyshare.in,
bangalore crowdfunding,
property crowdfunding,
bengaluru crowdfunding,
mumbai crowdfunding,
mumbai property crowdfunding,
crowdsourcing,
fintech,
igniteintent,
real estate share,
how to invest in property,
realty,
crowdfunding websites,
venturecrowd,
what is crowdfunding,
real estate investment,
ourcrowd,
assob,
indiegogo india,
equity crowdfunding,
on the property,
crowdfund,
crowdfundup,
crowdfunding sites,
crowd funding india,
property ladder,
gofundme.com,
crowd fund,
real estate sites,
crowdfunding in india,
fundraising india,
fundraising websites,
our crowd,
venture crowd,
chuffed.org,
equity crowdfunding india,
crowdfunding sites india,
property mogul,
artesian venture partners,
nathan cher,
pozible campaign,
pozible mumbai,
crowdfunder,
fundrise,
how does crowdfunding work,
crowdsourcing india,
best crowdfunding sites,
crowdfunding platforms,
real estate invest,
crowdsourcing websites,
india crowdfunding,
investing in real estate,
fundraising website,
moose ltd,
wishberry.com,
www.wishberry.com,
wishberry fees,
what is fintech,
groundbreaker,
wishberry crowdfunding,
crowdfunding definition,
chuffed crowdfunding,
fintech startups,
crowdfunding website,
croud funding,
india crowdfunding sites,
real estate crowdfunding,
crowd funding sites,
crowd sourced equity funding,
india crowdfunding,
crowd source funding,
what is crowd funding,
real estate investing,
invest in startups,
crowdfund sites,
largest crowdfunding sites,
crowdfunding sites for artists,
social crowdfunding sites,
crowdfunding equity sites,
crowdfund site,
local crowdfunding sites,
site crowdfunding,
sites for crowdfunding,
crowdfunding sites in india,
free crowdfunding sites,
european crowdfunding sites,
first crowdfunding site,
music crowdfunding sites,
crowdfunding sites for education,
film crowdfunding sites,
compare crowdfunding sites,
biggest crowdfunding platforms,
largest crowdfunding platforms,
open source crowdfunding platform,
crowdfunding open source platform,
crowdfunding platforms europe,
crowdfunding for websites,
website crowdfunding,
crowdfund websites,
equity crowdfunding websites,
crowdfunding websites in india,
crowdfunding website reviews,
group funding websites,
crowd source funding websites,
online funding websites,
top funding websites,
funding for website,
project funding website,
idea funding website,
website to raise funds,
funding platform websites,
micro funding websites,
fund raising websites,
business funding websites,
personal funding websites,
small business funding websites,
fund websites,
fund raiser website,
community funding websites,
equity crowdfunding platforms,
crowdfunding for equity,
crowdfunding equity based,
crowdfunding with equity,
crowdfund equity,
what is equity crowdfunding,
crowd funding sources,
crowd sourcing websites,
crowd sourcing funding,
group funding sites,
project funding sites,
internet funding sites,
crowding funding sites,
source funding sites,
business funding sites,
micro funding sites,
crowdfunding for businesses,
business crowdfunding sites,
best crowdfunding sites for business,
crowdfunding startup business,
crowdfund business,
crowdfunding for startup businesses,
crowdfunding for new business,
crowdfunding for business startup,
investing in crowdfunding,
crowdfunding equity investment,
invest crowdfunding,
crowdfunding investment websites,
crowdfunding investment sites,
investing crowdfunding,
best crowdfunding projects,
the best crowdfunding sites,
crowdfunding best sites,
crowdfunding best,
best crowdfunding for startups,
the best crowdfunding platforms,
best crowdfunded projects,
fundraising crowdfunding,
crowd fundraiser,
personal fundraising page,
self fundraising,
personal fundraising pages,
crowdsourced fundraising,
web fundraising,
fundraising for business start up,
donation pages for fundraising,
fundraising on the internet,
money raising websites,
website for raising money,
websites for raising money,
websites to raise money for projects,
websites that raise money,
raise money websites,
websites to raise money for a cause,
website to raise money for your project,
websites that help you raise money,
websites to help raise money,
raise money online for project,
how to raise money online,
raising money online for projects,
raising money online for business,
raise money online free,
raise money online for free,
raise money online for business,
online money raising,
sites to raise money,
site to raise money,
raise money sites,
sites to help raise money,
site to raise money for projects,
sites for raising money,
raising money sites,
money raising site,
fund raising site,
online crowdfunding platform,
crowdsourcing fundraising websites,
crowd investment,
crowd invest,
crowd investing websites,
crowd investing platform,
crowd funding investment,
top crowdfunding,
crowdfunding top sites,
crowdfunding community projects,
crowdfunded projects,
crowdfunding it projects,
crowdfunding social projects,
project crowdfunding,
crowdsourcing site,
crowdsourced investing,
crowdsourcing investment,
crowdsourcing crowdfunding,
crowdsourcing equity,
online crowdsourcing platforms,
list of crowdsourcing sites,
crowdsource investing,
number of crowdfunding platforms,
create a crowdfunding platform,
create crowdfunding platform,
what is a crowdfunding platform,
startup crowdfunding sites,
crowdfunding a startup,
private equity crowdfunding,
crowdfunding private equity,
equity crowdfunding real estate,
non equity crowdfunding,
indiegogo equity crowdfunding,
equity crowdfunding news,
sec equity crowdfunding,
sebi equity crowdfunding,
equity crowdfunding sec,
equity crowdfund,
equity crowdfunding france,
equity crowdfunding brasil,
is equity crowdfunding legal,
equity crowdfunding statistics,
equity crowdfunding nz,
crowdfunding portals,
crowdfundings,
crowdfunding 2014,
crowdfunding 2015,
crowdfunding 2016,
crowdfunding 2017,
private crowdfunding,
crowdfunds,
crowdfunding information,
crowdfunding social,
crowdfunding model,
crowdfunding securities,
crowdfunding inc,
crowdfunding returns,
crowdfunding pages,
crowdfunding tech,
crowdfunding donations,
crowdfunding community,
crowdfunding sources,
crowdfunding fund,
inc crowdfunding,
get crowdfunding,
crowdfunding fees,
crowdfunding stock market,
crowdfunding products,
crowdfunding for,
global crowdfunding,
european crowdfunding,
american crowdfunding,
crowdfunding organizations,
crowdfunding for the arts,
crowdfunding worldwide,
crowdfunding people,
crowdfunding assistance,
crowdfunding logo,
product crowdfunding,
crowdfunding in asia,
crowdfunding links,
crowdfunding it,
crowdfunding idea,
idea crowdfunding,
individual crowdfunding,
crowdfunding shares,
crowdfunding meaning,
crowdfunding pledge,
canada crowdfunding,
crowdfunding what is it,
crowdfunding legal fees,
legal crowdfunding,
crowdfunding bangalore,
Chunk technologies pvt ltd,
Chunk technologies private limited,
crowdfunding is,
crowdfunding or crowd funding,
crowdfunding exchange,
crowdfunding united states,
crowdfunding america,
crowdfunding crowdfunding,
whats crowdfunding,
crowdfund meaning,
what is crowdfund,
crowd funders,
crowd funding companies,
crowd founder,
crowd funding options,
crowd funding canada,
crowd fundinf,
crowd fnding,
crowd funding regulations,
crowd funding meaning,
crowd fund it,
crowd funding logo,
crowd fund raising,
crowd funfing,
crowd fudning,
crowd funding in canada,
crowd funding portal,
crowd funding us,
start up crowd funding,
sec crowd funding,
crowd fundung,
crowd financing sites,
funding crowd,
crowd funds,
crowd funding model,
crowd funding opportunities,
fund crowd,
crowd funding for individuals,
crowdfunding start up,
start up crowdfunding,
crowdfunding to start a business,
crowdfunding for business start up,
start crowdfunding,
start crowdfunding website,
start a crowdfunding website,
how to start a crowdfunding business,
how to start a crowdfunding platform,
starting a crowdfunding business,
starting a crowdfunding platform,
how to use crowdfunding to start a business,
when did crowdfunding start,
crowed founding,
project fundraising websites,
raise capital online,
crowdfuding,
crowdfungin,
funder.com,
estatebaron.com,
estate baron,
property crowd funding india,
property crowd funding australia,
property crowd funding sites,
property crowd funding websites,
crowdgunding,
crowdfounder,
funding companies,
to raise funding,
crownd funding,
corwd funding,
cowd funding,
crod funding,
cround funding,
crowd source funding for business,
crowd funding a business,
small business crowd funding,
crowd funding for small business,
crowd funding small business,
business crowd,
crowd funding startups,
crowd funding startup,
platform for startups,
platform startups,
how does equity crowdfunding work,
crowdsourced funding sites,
crowdsourcing funding for startups,
crowdsourcing funding sites,
crowdsourced funding for startups,
how to crowdsource funding,
crowd equity investment,
crowd funding equity,
crowd equity,
real estate crowdfunding india,
crowdfunding real estate uk,
crowdfund real estate,
crowdfunding in real estate,
crowdfunding real estate sites,
crowdfunding real estate investments,
real estate crowdfunding platform,
real estate crowdfunding sites,
crowdfunding real estate projects,
real estate crowdfunding platforms,
crowdfunding real estate investment,
real estate crowdfunding usa,
reality mogul,
investment mogul,
realestate mogul,
estate mogul,
micro real estate investing,
how to get financing for real estate investment,
investments real estate,
real state investment,
real estate investment trust,
real estate investment trust india,
REITs india,
REIT's india,
real estate investment,
how can i invest in real estate,
different ways to invest in real estate,
people looking to invest in real estate,
real estate where to invest,
real estate investment deals,
investing into real estate,
learn to invest in real estate,
where to invest real estate,
looking to invest in real estate,
how invest in real estate,
real estate investment firm,
real estate investment grants,
investing real estate,
crowdstreet,
rise funding,
collaperty,
realtymogul.com,
rise fund,
crowdbaron,
ifunding,
realtymogul,
realty shares,
fund rise,
realtyshares,
crowdfund insider,
realtyshares.com,
real estate funding sources,
private funding for real estate,
start a real estate fund,
how to create a real estate investment fund,
funding real estate,
real estate development funds,
real estate investment funds,
funding real estate investments,
funding real estate deals,
commercial real estate funding,
real estate funding,
private funding for real estate investors,
real estate private funding,
groundbreaker real estate,
real estate sector,
real estate tycoon,
real estate kickstarter,
global real estate conference,
into real estate,
real estate mongul,
kickstarter real estate,
kickstarter for real estate,
real estate development returns,
ifunding real estate,
crowdfunding top 10,
crowdfunding a house,
crowdfunding new york,
crowdfund mortgage,
realty crowdfunding,
mortgage crowdfunding,
crowdfunding mortgages,
house crowdfunding,
start a real estate investment company,
start real estate investing,
starting your own real estate investment company,
how to start a real estate development company,
how do i start a real estate investment company,
how to start a real estate investment firm,
start real estate investment company,
how to start real estate investment company,
starting a real estate investment company,
how to start a real estate investment company,
how to start real estate development company,
fundrise.com,
fundrise llc,
www.fundrise.com,
daniel miller fundrise,
ben miller fundrise,
property crowd funding,
crowd property,
crowd funding for property,
property crowd,
crowd source funding for real estate,
crowd sourced real estate,
crowd fund real estate,
crowd funded real estate,
private real estate investors,
how to find investors for real estate development,
new investors real estate,
investors looking to invest in real estate,
real estate development investors,
real estate investor sites,
real estate investor companies,
investors platform,
kickstarter intellectual property,
propertymoose,
crowd2let,
patch of land,
patchofland,
india startup.
online sector,
how to get on the property ladder,
property moose,
rise.com,
property investment project,
funding investment property,
asia crowdfunding,
crowdfunding indonesia,
crowdfunding for companies,
crowdfunding hong kong,
crowdfunding intellectual property,
who uses crowdfunding,
crowdfunding in asia,
crowdfunding england,
crowdfunding companies,
crowdfunding asia,
how to invest in property,
the house crowd,
crowd mortgage,
the home crowd,
crowd rise.com,
crowdrise,
crowd to let,
crowd house,
online crowd funding,
house crowd,
crowd investors,
crowd funded mortgage,
learn real estate investing,
why invest in real estate,
investment for startups,
investment in startups,
investment startup,
crowdfunding for development,
crowdfunding for real estate development,
crowdfunding development,
crowdfunding real estate development,
crowdfunding intellectual property,
realty mogul review,
realty mogul funding,
equity based crowdfunding sites,
best equity crowdfunding sites,
crowdfunding investment limits,
crowdfunding return on investment,
equity platform,
in real estate,
frontier real estate,
real estate projects,
crowdsource real estate,
crowdsourcing real estate,
real estate crowdsourcing,
commercial real estate investments,
how to raise capital for real estate investment,
invest in real estate online,
top real estate investment firms,
where to invest in real estate,
real estates sites,
sites for real estate,
real estate investment sites,
best sites for real estate,
crowdfunding platforms list,
crowdfunding list,
list of all crowdfunding sites,
list of crowdfunding platforms,
prodigy network,
real estate equity crowdfunding,
prodigy networks,
reality shares,
shares.com,
crowdfunding china,
crowdfunding belgium,
crowdfunding germany,
how to be a real estate investor,
private investors for real estate,
how to find private investors for real estate,
looking for real estate investors,
commercial real estate investors,
real estate moguls,
mogul.com,
realty investment company,
investment real estate company,
real estate investment companies,
real estate investing companies,
real estate website platform,
real estate web platform,
platform real estate,
real estate platform,
startup real estate,
best real estate startups,
how to get into real estate development,
investing in real estate development,
how to raise money for real estate development,
real estate development investment,
international crowdfunding,
international crowdfunding sites,
international crowdfunding platforms,
next hot,
groundbreakers,
realtyshare,
fox draw,
finding private investors for real estate,
private real estate investor,
real estate equity investors,
investors real estate,
private investors real estate,
real estate investors website,
real estate investor websites,
real estate investor website,
prodigy real estate,
real estate investment model,
real investments,
estate investment real,
crowdfunding for investors,
investor crowdfunding,
crowdfunding investor,
crowdfunding investors,
real estate investment financing,
real estate investor financing,
financing real estate investments,
investing in real estate funds,
private real estate investment funds,
real estate investment fund,
private real estate funds,
best real estate investing websites,
real estate investing website,
real estate investment website,
how to start a real estate investment business,
how to start investing in real estate,
how to get started in real estate investing,
crowd funding debt,
real crowd,
estate investment,
estate investments,
property crowdfunding uk,
crowdfunding uk property,
real estate development and investment,
real investment property,
top real estate development companies,
accredited investor crowdfunding,
www.chipin.com,
chipin,
chi pin,
crowfunding uk,
croud australia,
ourcrowd israel,
australian small scale offerings board,
ourcrowed,
fraud in equity,
ourcroud,
chipin.com,
match creative,
cat cafes,
crowfunding sites,
pozible irl shooter,
pozible.com.au,
irl shooter pozible,
www pozible com au,
pozible singapore,
pozible logo,
pozible melbourne aus,
pozibles,
what is pozible,
kickstarter for australia,
kickstarter australia version,
crowdfunding web,
government crowdfunding,
crowdfunding web design,
crowdfunding terms and conditions,
pledge crowdfunding,
world bank crowdfunding,
israel crowdfunding,
crowdfunding government,
how does crowdfunding make money,
crowdfunding in israel,
israeli crowdfunding,
is crowdfunding taxable,
usa crowdfunding,
crowdfunder review,
crowdfunding sydney,
nonprofit crowdfunding,
artist crowdfunding,
creative crowdfunding,
crowdfunding for artists,
crowdfunding venture capital,
crowdfunding for entrepreneurs,
crowdfunding resources,
ideas for crowdfunding,
for profit crowdfunding,
australian crowd,
crowd funding scams,
social crowd funding,
crowd funding new zealand,
our crowd israel,
crowd funding fraud,
crowd funding israel,
crowd funding ideas,
crowd funding singapore,
crowd funding for non profits,
crowd funding music,
crowdfunding australia small business,
australian fundraising website,
charity fundraising platform,
chip in fundraising,
enterprise fundraising,
chip fundraiser,
charity crowdfunding websites,
crowdfunding charity sites,
crowdfunding websites for charity,
crowdfunding sites for charity,
crowdfunding charities,
venture crowd australia,
crowdfunding tax,
crowdfunding tax implications,
do you have to pay taxes on crowdfunding,
crowdfunding tax deductible,
tax implications of crowdfunding,
is crowdfunding tax deductible,
are crowdfunding donations tax deductible,
crowdfunding tax issues,
taxes on crowdfunding,
crowdfunding and taxes,
crowdfunding for business uk,
business crowdfunding uk,
crowdfunding sites uk,
crowdfund uk,
uk equity crowdfunding,
top crowdfunding sites for nonprofits,
crowdfunding music sites,
crowdfunding sites singapore,
crowdfunding sites for entrepreneurs,
possible funding,
raising funds in australia,
raising capital australia,
how to raise capital in australia,
top crowdsourcing,
best crowdsourcing platforms,
crowd funding for charities,
crowd fundraising charity,
crowd funding charities,
crowd funding for charity,
equity funds australia,
equity law australia,
australia equity,
equity in australia,
crowdfunding for social entrepreneurs,
crowdfunding for social enterprise,
social enterprise crowdfunding,
crowdfunding art projects,
arts crowdfunding,
art crowdfunding,
crowdfunding art,
crowd source funding sites,
croud funding sites,
cloud funding site,
chip au,
chip in.com,
chip in australia,
chip australia,
crowdfunding education projects,
crowdfunding for education projects,
crowdfunding for community projects,
small investment opportunities australia,
artesian investments,
creative project funding,
funding for creative projects,
crowdfunding for non profit,
crowdfunding non profit,
charity platform,
platform australia,
creative crowdsourcing sites,
crowdsourcing web development,
crowdsourcing tasks,
crowdsourcing donations,
paid crowdsourcing,
crowdsourced web development,
crowdsourcing designs,
crowdsourcing model,
crowdsourcing science,
marketing crowdsourcing,
crowdsourcing companies,
online crowdsourcing,
crowdfunding and crowdsourcing,
crowdsourcing and crowdfunding,
personal fundraising websites,
fintech share price,
fintech stock,
fintech investments,
fintech investment,
fintech share,
fintech asset management,
fintech company,
fintech 2014,
fintech events,
fintech industry,
fintech consulting,
fintech consultants,
fintech sector,
top fintech companies,
fintech awards,
fintech market,
fintech vc,
www.fintech.net,
fintech media,
fintech venture capital,
fintech 50,
fintech limited,
fintech.net,
fintech connect,
fintech kenya,
fintech jobs,
fintech group,
startupbootcamp fintech,
fintech incubator,
fintech collective,
fintech wiki,
fintech definition,
fintech.com,
fintech securities,
fintech nyc,
fintech new york,
fintech global,
fintech market size,
fintech city,
fintech india,
fintech africa,
fintech ireland,
fintech recruitment,
fintech forum,
fintech blog,
fintech san francisco,
fintech careers,
level 39 fintech,
fintech top 50,
fintech fishing,
fintech logo,
fintech meaning,
fintech toronto,
fintech inc,
fintch,
innovationlab,
technology in finance industry,
finance companies list,
top 100 it services companies,
largest technology companies,
finance information technology,
fintec ltd,
jig fish,
partnership fund for new york city,
finance tech,
list of top finance companies,
investment boom,
jigfish,
fintech50,
tech fishing,
accelerator finance,
fintechweek,
finteck,
fintec group,
disruptive finance,
fintechcity,
biggest finance firms,
startupbootcamp london,
financial technologies,
financial services technology,
financial services technology companies,
technology in the financial services industry,
financial technology services,
financial information technology,
financial technology company,
financial technology sector,
financial service technology,
financial services technology awards,
first in financial technology,
what is financial technology,
financial technology definition,
fintech startups nyc,
financial services startups,
financial technology startups,
startups in financial services,
fin tech companies,
tech companies list,
tech company list,
top us tech companies,
pozible australia,
fintech companies,
financial technology,
ground breaker,
realty mogul,
ourcrowd australia,
pozible vs kickstarter,
fintech100,
crowdfunding process,
most funded crowdfunding,
venture crowdfunding,
real estate startup,
australia kickstarter,
financial technology companies,
real estate mogul,
crowd fundng,
kickstarter.com india,
fintech trends,
biggest crowdfunding sites,
equity based crowdfunding,
top crowd funding sites,
top crowdfunding platforms,
top 5 crowdfunding sites,
equity crowdfunding definition,
sec crowdfunding,
biggest crowdfunding,
crowdfunding article,
crowdfund it,
crowd funding laws,
crowd funding law,
crawd funding,
platform realty,
top equity crowdfunding sites,
real estate ii,
crowdfunding not for profit,
creative crowd,
what is equity law in australia,
crowdsourcing money,
crowdsourced,
fintech solutions,
fintech conference 2014,
fintech fund,
tech 50,
financial information technologies inc,
top fintech startups,
crowd raising websites,
australian crowdsourcing,
crowd raising india,
best crowdfunding platforms,
crowd funcing,
types of crowdfunding,
real estate startups,
fintechs,
fintech meetup,
equity crowdfunding platform,
top crowdfunding websites,
top ten crowdfunding,
how many crowdfunding platforms are there,
crowdfunding legislation,
crowdfunding laws,
crowd fundind,
crowdsourced funding platforms,
kickstarter in india,
non profit crowd funding,
crowdsourcing company,
crowdfunding crowdsourcing,
fintech accountants,
peert to peer lending,
peer to peer lending india,
peer to peer lending mumbai,
technology innovation in financial services,
crowdfund website,
international crowdfunding websites,
crowdfunding websites india,
portal crowdfunding,
crowd funded,
equity in startups,
crowdfunded real estate,
crowdfunding house,
real estate reality,
invest on,
what is a real estate investor,
real investment,
ato grants,
crowdfunding fraud,
crowd sourcing australia,
fintech week,
fintech south africa,
financial technology industry overview,
fintech startup,
fintech news,
fintech israel,
crowdfunding equity,
equity crowdsourcing,
does crowdfunding work,
best crowdfunding sites for nonprofits,
best crowdfunding websites,
crowdsourcing platform,
crowdsourcing projects,
fintech uk,
crowd funder,
financial startups,
free crowdfunding platform,
crowd sourcing website,
invest in crowdfunding,
crowdfunding projects,
crowdfunding startup,
equity crowdfunding rules,
crowdfunding what is,
crowd founding,
equitycrowdfunding,
crowdsourcing funding,
real estate crowdfunding websites,
crowdfunding legal issues,
crowdfunding for property,
crowdfunding for property,
what is real estate investment,
new zealand crowdfunding,
music crowd funding,
raising capital in australia,
crowdfunding for social causes,
non profit crowdfunding,
tech tackle,
financial services startup,
top crowdfunding sites,
equity crowdfunding sites,
best crowdfunding site,
how crowdfunding works,
fundriser,
social crowdfunding,
crowd fund property,
crowdfunding nz,
best crowdfunding website,
crowd fundig,
make money with crowdfunding,
capital raising australia,
crowdsourcing apps,
www.fintech,
funding site,
crowdsourcing platforms,
crowdunding,
charity crowd funding,
fintech conference,
singapore crowdfunding,
crowdfunding property,
crowdfunding property,
how to crowd fund,
possible crowdfunding,
crowd sourcing sites,
funding sites,
crowdfunding businesses,
investment based crowdfunding,
best crowdfunding platform,
crowdsourcing finance,
crowd found,
crowd fundings,
crowdsourcing funds,
equity based crowd funding,
crowdfunding.com,
list of crowdfunding,
crowdfunding israel,
crowd funding nz,
fintech funding,
fintech shares,
crowdfunding site,
crowd funding site,
top 10 real estate websites,
crowdfunding new zealand,
crowd sourced funding,
best crowdsourcing sites,
website funding,
best crowdfunding,
crowdfunding realestate,
best fintech startups,
crowdfunding how it works,
crowdfunding equity uk,
fintech conferences,
list of crowdfunding websites,
crowd investing,
crowdfunding real estate,
nz crowdfunding,
crowd funding platforms,
crowdfunding a business,
crowdsourcing sites,
list of crowdfunding sites,
top funding sites,
raising money online,
crowdfunding development projects,
equity crowdfunding canada,
crowdfunders,
crowd sourced financing,
crowed funding,
crowdfunding company,
crowd funding websites,
crowdfund investing,
cloud funding australia,
raise money website,
crowd donations,
crowd raising,
micro invest,
crowdfunding for nonprofits,
growd funding,
tech crowdfunding,
how does crowd funding work,
crowdfund property,
crowdfund property,
crowd fubding,
crowdfunding property development,
funding website,
crowdfunding investing,
crowdfunding investments,
raise money site,
crowdfunding canada,
crowd fundraising sites,
crowd funding business,
crowdfunding commercial real estate,
how to get funding for real estate investing,
micro crowdfunding,
online real estate investing,
canadian crowdfunding,
how to raise capital for real estate,
micro investments,
crowdfundraising,
not for profit crowdfunding,
best crowdfunding sites australia,
crowd funding charity,
crowdsourcing marketing,
fintech accelerator,
crowdfunding websites australia,
funding platform for creative projects,
crowdfunding platform,
crowd funding website,
crowd finance,
public funding sites,
crow funding,
crowdsource funding,
crowdfunding to buy a house,
crowd funding for real estate,
australian crowd funding,
raising money websites,
website to raise money,
start your own crowdfunding platform,
start your own crowdfunding site,
crowd funding real estate,
real estate as an investment,
real estate platforms,
equity crowd funding,
charity crowdfunding,
micro investment,
technology crowdfunding sites,
raising money website,
equity crowdfunding software,
crowdfunding finance,
community crowdfunding,
crowdfunding us,
real estate investors websites,
group funding australia,
crowd funding in australia,
crowd fundraising,
crowd funding uk,
crowdfunding social enterprise,
invest in startups australia,
fund raising website,
technology crowdfunding,
ways to invest in real estate,
australian crowd funding sites,
crowdfunding for real estate,
property crowdfunding,
crowdfunding uk,
invest real estate,
crowdfunding ideas,
start a crowdfunding site,
what is crowdfunding and how does it work,
fundrising,
rowd funding,
business crowdfunding,
group funding website,
money raising sites,
crowdfunding project,
startup crowd funding,
crowdfunding how does it work,
crowdfunding for charity,
crowdfunding for charities,
crowd source funding australia,
crowdfunding charity,
social enterprise funding australia,
free funding sites,
crowding funding,
how to invest in real estate,
crowd funded property,
australian crowdfunding platforms,
crowdfunding for everyone,
croed funding,
debt crowdfunding,
realestate investment,
crowdfunding for a cause,
crowd funding non profit,
australia fundraising,
crowd funding property,
micro investing,
crowdfunding arts,
crowdfunding sites for business,
money raising website,
crowdfunding startups,
commercial real estate investment,
fundraising in australia,
best crowdfunding sites for charity,
investment real estate,
investment crowdfunding,
crowdfunding for startups,
crowdfunding technology,
real estate investments,
funding websites,
crowdfunding investment,
funding for websites,
crowdfunding business startup,
online crowdfunding,
crowdfunding page,
crowd funding for business,
real estate crowdfunding uk,
crowdfunding property investment,
crowdfunding for business,
commercial real estate investing,
startup fundraising,
crowdsourcing website,
crowdfunding ranking,
crowd financing,
business crowd funding,
fundraising sites australia,
fundraising websites australia,
online fundraising australia,
crowdfunding investment opportunities,
crowdfunding usa sites,
charity crowdfunding sites,
project funding websites,
raise funds website,
start up funding websites,
business funding website,
online funding sites,
crowdfunding business,
business startup crowdfunding,
crowdfunding for business startups,
investment crowdfunding sites,
how to invest in crowdfunding,
crowdfunding fundraising,
internet fundraising,
fundraising business,
business fundraising,
fundraising for business,
websites to raise money,
raise money online,
online money raising for projects,
how to raise money online for a personal cause,
sites to raise money for projects,
fund raising sites,
crowdfunding online,
crowdsourcing websites list,
crowd investing sites,
top ten crowdfunding sites,
startup crowdfunding,
startups crowdfunding,
crowdfunding sites for startups,
crowdfunding help,
crowdfunding opportunities,
internet crowdfunding,
crowdfunding for individuals,
crowdfunding options,
crowdfunding legal,
crowd fundin,
crowd funding usa,
crowd funding company,
crowd fundimg,
crwd funding,
crowd funding for businesses,
crowd funding for startups,
crowd equity funding,
crowdfunding real estate loans,
real estate investment business,
invest in real estate,
how to get into real estate investing,
crowdfunding mortgage,
how to start real estate investing,
crowd funding for property development,
real estate crowd funding,
buy ladder,
property investment funds,
crowdfunding singapore,
investment in real estate,
real estate investment group,
invest in startups for equity,
startups investment,
investment startups,
real estate investment opportunities,
real estate investment company,
crowdfunding international,
real estate investor loans,
local real estate companies,
real estate development financing,
invest in property development,
how to raise money through crowdfunding,
crowdfunding artists,
fundraising online australia,
fundraising website australia,
fundraising platforms,
crowdfund charity,
crowdfunding uk sites,
capital raising in australia,
cloud funding sites,
fundraiser website,
fundraiser websites,
personal fundraising website,
which crowdfunding site to use,
new crowdfunding sites,
equity crowdfunding site,
crowdfunding europe sites,
sites crowdfunding,
medical crowdfunding sites,
new crowdfunding platforms,
platform crowdfunding,
crowdfund platform,
crowdfund platforms,
european crowdfunding platforms,
how to create a crowdfunding platform,
micro funding website,
funding website kickstarter,
start up funding website,
crowd source funding uk,
web funding sites,
startup funding site,
project funding site,
crowdfunding sites for business startups,
business crowdfunding platform,
crowdfunding invest,
investment crowdfunding platform,
best crowdfunding sites for startups,
best crowdfunding sites for individuals,
the best crowdfunding site,
web fundraising company,
how to start an online fundraiser,
website to raise money for projects,
website for raising money for projects,
website to raise money for a cause,
raise money online for projects,
online crowdfunding sites,
online crowdfunding websites,
crowdsource funding websites,
list of crowdsourcing websites,
crowd investments,
top ten crowdfunding websites,
crowdfunding top,
project crowdfund,
crowdfunding for web projects,
idea crowdsourcing platform,
crowdfunding tech startups,
crowdfund startups,
crowdfunding f端r startups,
equity crowdfunding portals,
equity crowdfunding portal,
saskatchewan equity crowdfunding,
equity crowdfunding pdf,
l equity crowdfunding,
securities crowdfunding,
crowdfunding stock,
new crowdfunding,
crowdfunding internet,
crowdfunding english,
crowdfunding overview,
campaign crowdfunding,
the crowdfunding,
crowdfunding global,
crowdfunding crowdfunding crowdfunding,
web crowdfunding,
california crowdfunding,
crowdfunder inc,
crowdfunding legislation 2013,
what is crowdfunder,
founding crowd,
crowd funding network,
crowd funding international,
crowd funding sec,
crowd fonding,
crowd donating,
start a crowdfunding platform,
croudfunder,
crowdinvesting platforms,
crowdinvesting platform,
crownd founding,
crawd founding,
croudfunding sites,
cround founding,
group funding for business,
invest in startup companies online,
crowdsource startup funding,
what is crowdsourcing funding,
crowdfunding real estate canada,
crowdfunding for commercial real estate,
commercial real estate crowdfunding,
crowdfunding for real estate investments,
crowdfunding sites for real estate,
crowdfunding for real estate projects,
real estate investment crowdfunding,
ground floor real estate crowdfunding,
real estate crowdfunding canada,
real estate crowdfunding news,
investment moguls,
investing in real state,
real estate to invest in,
how to invest commercial real estate,
real estate investment project,
real estate investing firm,
real state investing,
private real estate investment,
real estate investment pool,
grants for real estate investing,
how to invest in real state,
real estate investment co,
investing in real estates,
how real estate investing works,
how to get into real estate investment,
reality shares inc,
real estate development funding sources,
how to fund real estate investment,
how to fund real estate deals,
how to start an investment fund for real estate,
how to create a real estate fund,
funding for real estate development,
real estate funding companies,
funding for real estate projects,
how to start a real estate investment fund,
start a real estate investment fund,
how to start a real estate fund,
starting a real estate fund,
real estate investment funding,
real estate development funding,
funding for real estate investors,
funding for real estate investing,
real estate funding for investors,
funding for real estate,
real estate investor funding,
real estate project funding,
commercial real estate funding sources,
real estate fund raising,
starting a real estate investment fund,
real estate website project,
ben miller real estate,
kickstarter for real estate,
top crowdfunding companies,
new york crowdfunding,
crowdfunding nyc,
groundbreaker crowdfunding,
how to start real estate investment,
start real estate investing company,
how to start an real estate investment company,
how to start a real estate investment group,
starting a real estate development company,
starting a real estate investment group,
starting real estate investment company,
starting a real estate investment firm,
benjamin miller fundrise,
fundrise washington dc,
fundrise ben miller,
fundrise real estate,
crowd investing real estate,
crowd source funding real estate,
crowd source real estate,
crowd sourcing real estate,
crowd real estate,
grants for real estate investors,
investor for real estate project,
investors for real estate projects,
local real estate investors,
colorado real estate investors,
money for real estate investors,
how to find real estate investors online,
how to get investors for real estate development,
real state sector,
property moose limited,
crowd2let review,
crowd2let reviews,
www.realtymogul.com,
to let.com,
funding for investment properties,
accredited crowdfunding,
crowd investor,
crowd 2 let,
crowd funding asia,
house crowd review,
crowd funding mortgage,
crowd funding mortgages,
crowdsourcing real estate investment,
epic real estate investing,
real estate investing firms,
real estate investment startup,
realty mogul crowdfunding,
realty mogul co,
realty mogul fees,
equity based investment,
crowdsourcing for real estate,
real estate investing online,
real online investment,
sites real estate,
real estate investing sites,
list of crowdfunding companies,
crowdfunding sites list,
crowdfunding websites list,
www.uinvest.com.ua,
4 shares.com,
crowdfunding portal,
crowdfunding switzerland,
investors in real estate,
investment real estate companies,
real estate investing company,
raising capital for real estate development,
real estate investment development,
real estate development startup,
real estate investment and development,
international crowdfunding site,
equity investors real estate,
private equity real estate investors,
real estate private investors,
website for real estate investors,
best real estate investor websites,
websites for real estate investors,
investment opportunities in real estate,
investment real,
real estate investment models,
private real estate investing,
real estates investment,
real estates investments,
best real estate investment opportunities,
best crowdfunding sites for investors,
my micro invest,
real estate financing for investors,
investor financing real estate,
financing for real estate investors,
real estate investing websites,
best real estate investment websites,
real estate investment websites,
starting a real estate investment business,
crowd funding website development,
investment estate,
invest estate,
estate invest,
estate investing,
investment real estate properties,
crowdfunding for non accredited investors,
crowdfunding non accredited investors,
non accredited investor crowdfunding,
crowdfunding accredited investors,
sites like chipin,
www.aflamnah.com,
crowfunding site,
be part of something big .comau,
www.kickstarter australia,
crowdfunding profit,
crowdfunding taxation,
raise money crowdfunding,
independent crowdfunding,
crowdfunding hungary,
crowd funding for nonprofits,
crowd fund uk,
best crowdfunding sites canada,
crowdfunding social entrepreneurs,
social entrepreneurship crowdfunding,
www.chip.in,
chip charity,
crowdfunding charity projects,
fund creative projects,
funding creative projects,
crowdfunding for non profits,
non profit crowdfunding platform,
crowdfunding non profits,
crowdsource tasks,
crowdsourcing international,
crowdsourcing micro tasks,
fintech stock price,
fintech investors,
fintech m&amp;a,
fintech private equity,
fintech abrasives,
fintech 2013,
fintech llc,
fintech partnerships,
fintech bee certificate,
fintech partners,
aurora fintech solutions,
fintech 50 2014,
fintech tampa,
fintech teknoloji hizmetleri,
fintech zimbabwe,
fintech global capital,
fintech challenge,
fintech germany,
fintech group germany,
fintech advisors,
di fintech,
fintech atlanta,
fintech tampa fl,
fintech communications,
fintech canada,
boston fintech,
fintech boston,
finance software companies,
fintec inc,
fintec 2014,
electropolishing houston,
www.tackle-craft.com,
top technologies in it industry,
top 100 technology companies 2012,
top 100 technology companies 2013,
top 100 tech stocks,
john lavey first data,
top us technology companies,
financial technology firms,
financial technology industry,
technology in financial services industry,
financial technology innovation,
financial technology market,
technology redefines financial services,
association of financial technology,
fintech startups conference,
ny fintech startups,
financial tech startups,
startup financial services,
startups financial services,
financial startups london,
top financial startups,
best financial startups,
top tech companies in India
" name="keywords" />
	<meta content="width=device-width, investmentitial-scale=1.0" name="viewport" />
	<meta content="PropChunk CrowdInvesting" name="author" />
	<meta content="Invest in Mumbai Real Estate Developments from Rs. 1 Lakh. View listing now." name="description" />
	<meta content="Chunk Technologies Pvt. Ltd. copyright (c) 2016" name="copyright" /><!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
	<link href="<?php echo base_url('/public/assets/css/main.css');?>" rel="stylesheet" />
	<link href="<?php echo base_url('/public/assets/css/animate.css'); ?>" media="all" rel="stylesheet" type="text/css" />
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">-->
	<link href="<?php echo base_url('/public/images/favicon-16x16.png'); ?>" rel="icon" sizes="16x16" type="image/png" /><!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]--><!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.0/slick.css" rel="stylesheet"/>
<link href="<?php echo base_url('/public/assets/css/slider.css'); ?>" rel="stylesheet"/>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css">   



<script type="text/javascript">
var ua = navigator.userAgent.toLowerCase(),
platform = navigator.platform.toLowerCase();
platformName = ua.match(/ip(?:ad|od|hone)/) ? 'ios' : (ua.match(/(?:webos|android)/) || platform.match(/mac|win|linux/) || ['other'])[0],
isMobile = /ios|android|webos/.test(platformName);
if (!isMobile) {
   		window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
		d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
		_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
		$.src="//v2.zopim.com/?3jVJ1R4O7lZX1sYjbJuTx4UaycsjKb99";z.t=+new Date;$.
		type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
}
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-74817276-1', 'auto');
  ga('send', 'pageview');

</script>

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');

fbq('init', '1580135885558351');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1580135885558351&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Begin Inspectlet Embed Code -->
<script type="text/javascript" id="inspectletjs">
window.__insp = window.__insp || [];
__insp.push(['wid', 1059807]);
(function() {
function ldinsp(){if(typeof window.__inspld != "undefined") return; window.__inspld = 1; var insp = document.createElement('script'); insp.type = 'text/javascript'; insp.async = true; insp.id = "inspsync"; insp.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://cdn.inspectlet.com/inspectlet.js'; var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(insp, x); };
setTimeout(ldinsp, 500); document.readyState != "complete" ? (window.attachEvent ? window.attachEvent('onload', ldinsp) : window.addEventListener('load', ldinsp, false)) : ldinsp();
})();
</script>
<!-- End Inspectlet Embed Code -->
   
</head>

<body class="landing"><!-- Page Wrapper -->
<div id="page-wrapper"><!-- Header -->
<header class="alt" id="header"><img src="<?php echo base_url('/public/images/beta-label.png'); ?>" />
<h1><a href="http://propchunk.com/" style="color:white;">&nbsp; &nbsp; Prop Chunk</a></h1>

<nav id="nav">
<ul>
	<li class="special"><a class="menuToggle" href="#menu"><span>Menu</span></a>

	<div id="menu">
	<ul>
											<li><a href="<?php echo site_url('Home');?>">Home</a></li>
											<li><a href="#">Browse Projects</a></li>
											<li><a href="#">Investor Protection</a></li>
										<li class="int-drop">
										
		                        	<span>Learn</span>
		                        	<a href="#">How it works</a>
		<a href="<?php echo site_url('Home/faq');?>">FAQ's</a>
		<a href="<?php echo site_url('Home/about_us');?>">About us</a>
		<a href="<?php echo site_url('Home/contact');?>">Contact Us</a>
		<a href="<?php echo site_url('');?>">Blog</a>
	     </li>
	     <li> <a href="<?php echo site_url('Home/auth');?>">Login/SignUp</a></li>
		<!-- 											<li><a href="#">Sign Up</a></li>
											<li><a href="about.html">About Us</a></li>
											<li><a href="contact.html">Contact Us</a></li> -->
	</ul>
	</div>
	</li>
</ul>
</nav>

<ul class="top-nav" id="right">
<li>
	
		<a href="#">Browse Project</a>
	</li>
<li>
	
		<a href="#">Investor Protection</a>
	</li>

<li>
	<div class="top-dropdown">
		<span class="ab">Learn&nbsp;<i class="icon fa-angle-down"></i></span>
	<div class="dropdown-content" id="down">
		<a href="<?php echo site_url('Home/faq');?>">FAQ's</a>
		<a href="<?php echo site_url('Home/about_us');?>">About us</a>
		<a href="<?php echo site_url('Home/contact');?>">Contact Us</a>
		<a href="<?php echo site_url('');?>">Blog</a>
	</div>	
</div>
</li>

<li class="padd">
	
		<a href="<?php echo site_url('Home/auth');?>" class="button special small 1">Login/SignUp</a>
	
</li>
</ul>
</header>
<!-- Banner -->
<section id="banner">
<div class="inner">
<h2 style="font-size: 190%;">PROP CHUNK</h2>

<p>OWN A PIECE OF MUMBAI<br />
FOR AS LITTLE AS <span style="white-space:pre;"><b><i class="fa fa-inr"></i> 1 LAKH *</b></span><br />
<pre><i><a href="https://twitter.com/hashtag/FractionalOwnership" style="text-transform: none;" target="_blank">#FractionalOwnership</a> </i></pre></p>
&nbsp;

<section>
<form action="#" method="post">
<div class="row uniform" style="display: flex;flex-direction: row;flex-wrap: wrap;justify-content: center;align-items: center;"><!-- <div class="10u$ 9u$(small) 12u$(xsmall)">Register for the private beta launch</div> <br/> --><!-- <div class="4u$ 6u$(medium) 10u$(small) 12u$(xsmall)">
												<input type="text" name="demo-email" id="demo-email" value="" placeholder="Email Address" />
											</div> --><!--<div class="12u$">
												<ul class="actions">
													<li><a href="#openModal" class="button fit special">Sign Up for Official Launch</a></li>
														<div id="openModal" class="modalDialog">
															<div>
																<a href="#close" title="Close" class="close">X</a>
																<iframe id="my_typeform" src="https://propchunk.typeform.com/to/VL6Pxs"></iframe>
															</div>
														</div>
												</ul>
											</div> -->
<div class="12u$">
<ul class="actions">
	<li><!-- <input type="submit" value="Send Message" class="special"> --><a class="button fit special typeform-share button" data-mode="1" href="https://propchunk.typeform.com/to/VL6Pxs" target="_blank">Sign Up in 30 seconds</a> <script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'share.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}id=id+'_';if(!gi.call(d,id)){qs=ce.call(d,'link');qs.rel='stylesheet';qs.id=id;qs.href=b+'main.css';s=gt.call(d,'head')[0];s.appendChild(qs,s)}})()</script>

	<p>Get exclusive Launch access.</p>
	</li>
</ul>
</div>
</div>
</form>
</section>
</div>
<a class="more scrolly" href="#one">Learn More</a></section>
<!-- One -->

<section class="wrapper style1 special" id="one"><!-- <div class="inner"> -->
<header class="major">
<h2>How It Works</h2>

<p>It is as easy as 1-2-3</p>
</header>
<!--	<ul class="icons major">
								<li><span class="icon fa-diamond major style1"><span class="label">Lorem</span></span></li>
								<li><span class="icon fa-heart-o major style2"><span class="label">Ipsum</span></span></li>
								<li><span class="icon fa-code major style3"><span class="label">Dolor</span></span></li>
							</ul> -->

<div class="box alt">
<div class="row uniform 50%" style="word-wrap: break-word;">
<div class="4u wow fadeIn animated" data-wow-delay="0.8s" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 0.8s; animation-name: fadeIn;">
<div class="text-center" style="color:#505393;">
<i class="fa fa-search fa-5x"></i>
<h4><br />
Select a property</h4>
</div>
&nbsp;

<p class="text-justify" style="color: #381417;">Browse through a list of highly curated properties with. All of the properties listed undergo stringent due diligence and have a high appreciation potential.</p>
</div>

<div class="4u wow fadeIn animated" data-wow-delay="0.8s" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 0.8s; animation-name: fadeIn;">
<div class="text-center" style="color:#505393;">
<i class="fa fa-inr fa-5x"></i>
<h4><br />
Invest Fractionally</h4>
</div>
&nbsp;

<p class="text-justify" style="color: #381417;">Decide on how much % of the selected property you want to own and invest only a fraction of the total sum. You become a #FractionalOwner !</p>
</div>

<div class="4u wow fadeIn animated" data-wow-delay="0.8s" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 0.8s; animation-name: fadeIn;">
<div class="text-center" style="color:#505393;">
<i class="fa fa-line-chart fa-5x"></i>
<h4><br />
WATCH IT GROW</h4>
</div>
&nbsp;

<p class="text-justify" style="color: #381417;">Monitor progress of your investments and earnings via an investor dashboard, while we handle all hassles of buying, selling, and managing the property</p>
</div>
</div>
</div>
<!-- </div> --></section>
<!-- Two -->

<section class="wrapper style2 special" id="two">
<div class="inner">
<header class="major">
<h2>NOW FUNDING</h2>

<p>View Properties that are being funded currently or upcoming.</p>

   <div class="slider" align="center" >
   <div class="box1">
                        <img src="https://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>20 Lakhs </h2><p style=" color: black;">Coming Soon</p>
                        <table align="center">
                        	
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>20%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>12 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Palghar, MH</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="http://www.everbluetraining.com/sites/default/files/u47558/commercial-buildings.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>25 Lakhs </h2><p style=" color: black;">Coming Soon</p>
                        <table>

                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>17.5%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>36 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Bhivpuri, MH</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="http://www.eschervictoria.com/wp-content/uploads/2014/06/ESR-building-exterior.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>22Lakhs </h2><p style=" color: black;">Coming Soon</p>
                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>12%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>9 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Atlanta, GA</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="http://www.nrc-cnrc.gc.ca/obj/images/achievements-realisations/highlights-saillants/2010-2010/green_building-batiment_ecologique_1.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>18 Lakhs </h2><p style=" color: black;">Coming Soon</p>                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>20%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>12 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Virar, MH</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="https://www.nd.edu.au/images/building_projects/newedubuilding.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>22.5 Lakhs </h2><p style=" color: black;">Coming Soon</p>
                                               <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>19%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>24 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Ulwe, MH</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="http://ms-development.co.za/wp-content/uploads/2015/05/green-building-district-wallpaper-user-1920x1200.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>30 Lakhs </h2><p style=" color: black;">Coming Soon</p>                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>20%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>12 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Shahapur, MH</td>
                            </tr>
                        </table>
                        

                </div>
                <div class="box1">
                        <img src="http://www.yorku.ca/susweb/images/buildings1.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>26 Lakhs </h2><p style=" color: black;">Coming Soon</p>                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>15%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>12 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Taloja, MH</td>
                            </tr>
                        </table>
                        

                </div>
                 <div class="box1">
                        <img src="https://www.aoc.gov/sites/default/files/styles/artwork-node/public/images/buildings/6309112271_ae691e3d3f_o.jpg"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>20 Lakhs </h2><p style=" color: black;">Coming Soon</p>                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>19%</td>
                                
                            </tr>
                            <tr>
                                <td>Term</td>
                              
                                <td>12 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Karjat, MH</td>
                            </tr>
                        </table>
                        

                </div>
                 <div class="box1">
                        <img src="https://www.chem.wisc.edu/deptfiles/content/CBP-UniversityAve-2.png"  width="339" height="179" />
                        <h2 style="color:#ed4933;" align="center"><i class="fa fa-inr"></i>24 Lakhs </h2><p style=" color: black;">Coming Soon</p>                        <table>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            <tr>
                                <td>Ann.Return</td>
                              
                                <td>10%</td>
                            </tr>
                            <tr>
                                <td>Term</td>
                                <td>18 mo</td>
                            </tr>
                             <tr>
                                <td>Location</td>
                              
                                <td>Vasai, MH</td>
                            </tr>
                        </table>
                        

                </div>
        </div>
        <br/>
        <br/>
</header>
</div>
</section>
<!-- Three -->

<section class="wrapper alt style3" id="three">
<center style="padding: 6.5em 0 0.75em 0;">
<header class="major">
<h2>ADVANTAGES</h2>

<p>Why #FractionalOwnership is the future of safe, high-return investments</p>
</header>
</center>
<section class="spotlight">
<div class="image"><img alt="" src="<?php echo base_url('/public/images/pic01.jpg'); ?>" /></div>

<div class="content">
<h2>Small investment, Large returns</h2>

<p>Indians love property, and it is a great asset to invest in. But investing in real estate typically requires huge amounts of money, locking out most investors. That is until now...<br />
We are enabling Indian investors to enjoy superior returns of Real Estate, while investing amounts as little as <i class="fa fa-inr"></i> 1 Lakh.</p>
</div>
</section>

<section class="spotlight">
<div class="image"><img alt="" src="<?php echo base_url('/public/images/pic02.jpg'); ?>" /></div>

<div class="content">
<h2>No burden of loans</h2>

<p>No more paying EMI&#39;s all your life. If you take a loan to invest in real estate, the interest you pay on the loan kills the appreciation of the property</p>
</div>
</section>

<section class="spotlight">
<div class="image"><img alt="" src="<?php echo base_url('/public/images/pic03.jpg'); ?>" /></div>

<div class="content">
<h2>Directly own a Chunk !</h2>

<p>By investing in one of our campaigns, you become an official partner/shareholder of a Special Purpose Vehicle (SPV). The property is purchased in the Name of this SPV, which means you have direct ownership of assets you invest in.</p>
</div>
</section>

<section class="spotlight">
<div class="image"><img alt="" src="<?php echo base_url('/public/images/pic04.jpg'); ?>" /></div>

<div class="content">
<h2>Professionally managed</h2>

<p>We focus on managing your property, so that you can focus on your life. We handle everything - right from due diligence of the property and builder, buying real estate, collecting and scrutinizing all documents like sale agreement, formation of SPV, management of payments, duties, taxes, and finally selling off the property</p>
</div>
</section>
</section>
<!-- Testimonials -->

<section class="wrapper style2 special" id="three">
<div class="inner">
<header class="major">
<h2>TESTIMONIALS</h2>

<p>What people are saying about us.</p>
</header>

<ul class="features" style="background-color: #505393;">
	<li>
	<h3 style="color: rgb(255, 255, 255);">Kunal Dhuri, Banker</h3>

	<p>PropChunk provides me with a great alternative investment to diversify my portfolio. The returns are way better as compared to other financial instruments and the transactions are transparent. Looking forward to more investments in the future!</p>
	</li>
	<li>
	<h3 style="color: rgb(255, 255, 255);">TRM Nayar, LIC Agent</h3>

	<p>What I loved about PropChunk was the ability to invest with very small amounts in projects of my choice. All the details were explained in a simple and transparent fashion. Where else can I invest as little as <i class="fa fa-inr"></i> 3 Lakhs and get a 20% return. And all of this in a blue chip area! Wish all property investing was as simple as this.</p>
	</li>
</ul>
</div>
<!-- </div> --></section>
<!-- Call To Action -->

<section class="wrapper style4" id="cta">
<div class="inner">
<header>&nbsp;
<h2>What are you waiting for?</h2>

<p><i>You don&#39;t become rich by saving, you become rich by investing.</i> With our curated deals in growing geographies, you can be a property owner too.</p>
</header>

<ul class="actions vertical">
	<li><br />
	<a class="button fit special typeform-share button" data-mode="1" href="https://propchunk.youcanbook.me/?skipHeaderFooter=true" target="_blank">Fix A Meet Now</a> <script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'share.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}id=id+'_';if(!gi.call(d,id)){qs=ce.call(d,'link');qs.rel='stylesheet';qs.id=id;qs.href=b+'main.css';s=gt.call(d,'head')[0];s.appendChild(qs,s)}})()</script></li>
	<li><a class="button fit" href="faq.html">Learn More</a></li>
	<br />
	<br />
	<br />
	<br />
	&nbsp;
</ul>
</div>
</section>
<!-- Footer -->

<footer id="footer">
<ul class="icons">
	<li><a class="icon fa-facebook-official fa-2x" href="https://www.facebook.com/PropChunk/" style="color: #3b5998"><span class="label">Facebook</span></a></li>
	<li><a class="icon fa-twitter-square fa-2x" href="https://twitter.com/PropChunk" style="color: #0084b4"><span class="label">Twitter</span></a></li>
	<!-- <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
							<li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li> -->
</ul>

<ul class="copyright">
	<li><br />
	<br />
	<br />
	D/9, Ansa Estate,  <br />
	<br />
	Opp. Kotak Bank & Vodafone Gallery,<br />
	<br />
	Saki Naka, Andheri (E), Mumbai.</li>
	<li><br />
	<br />
	<br />
	hello@propchunk.com<br />
	<br />
	<br />
	<br />
	&nbsp;</li>
	<li><br />
	<br />
	<br />
	+91 9699 796629<br />
	<br />
	<br />
	<br />
	&nbsp;</li>
	<li><br />
	<br />
	<br />
	&copy; 2016. All Rights Reserved.<br />
	<br />
	Chunk Technologies Pvt. Ltd.<br />
	<br />
	&nbsp;</li>
	<!-- <li>Design: <a href="http://html5up.net">HTML5 UP</a></li> -->
</ul>

<ul class="disclosure">
	<li>
	<p>*Important Disclosure:&nbsp;<a href="https://www.propchunk.com/">PropChunk.com</a>&nbsp;is a website operated by CHUNK TECHNOLOGIES PVT. LTD. and by accessing the website and any pages thereof, you agree to be bound by its&nbsp;<a href="terms.html" target="_blank">Terms of Service</a>&nbsp;and&nbsp;<a href="privacy-policy.html" target="_blank">Privacy Policy</a>. CHUNK TECHNOLOGIES PVT. LTD. and its platform PropChunk operate in Maharashtra and are registered with the Registrar Of Companies, Maharashtra.</p>

	<p>PropChunk.com is intended for all investors who are signed up online or offline with PropChunk and familiar with and willing to accept the risks associated with private investments. Securities sold through private placements are not publicly traded and are intended for investors who do not have a need for liquidity in their investment.</p>
	<!-- <p>&nbsp;</p> -->

	<p>PropChunk does not make investment recommendations, and no communication through this website or in any other medium should be construed as such. Investment opportunities posted on this website are &quot;private placements&quot; of securities that are not publicly traded, are subject to holding period requirements, and are intended for investors who do not need a liquid investment. Private placement investments are NOT bank deposits (and thus NOT insured by the any state or central governmental agency), are NOT guaranteed by PropChunk or CHUNK TECHNOLOGIES PVT. LTD., and MAY lose value. Neither the SEBI nor any central or state securities commission or regulatory authority has recommended or approved any investment or the accuracy or completeness of any of the information or materials provided by or through the website. Investors must be able to afford the loss of their entire investment.</p>
	<!-- <p>&nbsp;</p> -->

	<p>Testimonial statements are from existing PropChunk investors. These statements may not be representative of the experience of all clients, and are not a guarantee of future performance or success.</p>
	<!-- <p>&nbsp;</p> -->

	<p>Articles or information from third-party media outside of this domain may discuss PropChunk or relate to information contained herein, but PropChunk does not approve and is not responsible for such content. Hyperlinks to third-party sites, or reproduction of third-party articles, do not constitute an approval or endorsement by PropChunk of the linked or reproduced content.</p>
	<!-- <p>&nbsp;</p> -->

	<p>The investor fees are specific to each investor. Other fees may be applicable to sponsors or borrowers.</p>
	<!-- <p><span>&nbsp;</span></p> -->

	<p>Any financial projections or returns shown on the website are estimated predictions of performance only, are hypothetical, are not based on actual investment results and are not guarantees of future results. Estimated projections do not represent or guarantee the actual results of any transaction, and no representation is made that any transaction will, or is likely to, achieve results or profits similar to those shown. Any investment information contained herein has been secured from sources that PropChunk believes are reliable, but we make no representations or warranties as to the accuracy of such information and accept no liability therefore. Offers to sell, or the solicitations of offers to buy, any security can only be made through official offering documents that contain important information about risks, fees and expenses. Investors should conduct their own due diligence, not rely on the financial assumptions or estimates displayed on this website, and are encouraged to consult with a financial advisor, attorney, accountant, and any other professional that can help you to understand and assess the risks associated with any investment opportunity.</p>
	<!-- <p>&nbsp;</p> -->

	<p>&copy; 2016 CHUNK TECHNOLOGIES PVT. LTD., All Rights Reserved.</p>
	</li>
</ul>
</footer>
</div>
<!-- Scripts --><script src="<?php echo base_url('/public/assets/js/jquery.min.js'); ?>"></script><script src="assets/js/jquery.scrollex.min.js"></script><script src="assets/js/jquery.scrolly.min.js"></script><script src="assets/js/skel.min.js"></script><script src="assets/js/util.js"></script><!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]--><script src="assets/js/main.js"></script><script src="assets/js/wow.min.js"></script>
<!-- <script src="//my.hellobar.com/c4a765d72f15ab36c9264c49588ec74ca69d5d0d.js" type="text/javascript" charset="utf-8" async="async"></script> -->
			<script>
  (function (w,i,d,g,e,t,s) {w[d] = w[d]||[];t= i.createElement(g);
    t.async=1;t.src=e;s=i.getElementsByTagName(g)[0];s.parentNode.insertBefore(t, s);
  })(window, document, '_gscq','script','//widgets.getsitecontrol.com/38404/script.js');
</script>

<script src="//my.hellobar.com/c4a765d72f15ab36c9264c49588ec74ca69d5d0d.js" type="text/javascript" charset="utf-8" async="async"></script>

<script src="//my.hellobar.com/c4a765d72f15ab36c9264c49588ec74ca69d5d0d.js" type="text/javascript" charset="utf-8" async="async"></script>
<script>
    peekin = {api_key: "3b0f2b9c602dd2889bb0"};
</script>
<script src="//cdn.peekin.io/peekin.js" async></script>


 <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
  <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.0/slick.js"></script>
   <script>
 $(document).ready(function() {

    $('.slider').slick({
        // dots: true,
        infinite: true,
    
        arrows:true,
        autoplay:true,
        autoplaySpeed:2000,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                // centerMode: true,

            }

        }, {
            breakpoint: 800,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                dots: true,
                infinite: true,

            }


        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                dots: true,
                infinite: true,
                
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
            }
        }]
    });


});
        </script>

</body>
</html>