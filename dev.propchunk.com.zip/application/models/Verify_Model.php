<?php

Class Verify_Model extends CI_Model {

	public function checkhash($hash){
		$query = $this->db->where(['HashKey' => $hash])->get('RegisteredUser');
		if($query){
			$this->db->where('HashKey',$hash);
			$data = array('ActiveLevel' => 1, );
			$this->db->update('RegisteredUser',$data);
			return TRUE;
		}
		else{

			return FALSE;

		}
	}

}
?>