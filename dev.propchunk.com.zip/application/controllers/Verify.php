<?php

Class Verify extends CI_Controller {

	public function __construct() {
		parent::__construct();

		// Load database
		$this->load->model('Verify_Model');
	}

	public function email_verify($hash){

		$response=$this->Verify_Model->checkhash($hash);
		if($response==true){
			return redirect('Home/');	
		}else{
			return redirect('');
		}
	}




}



?>