<?php

Class Auth extends CI_Controller {

	public function __construct() {
		parent::__construct();

		// Load form helper library
		$this->load->helper('form');

		// Load form validation library
		$this->load->library('form_validation');

		// Load session library
		$this->load->library('session');

		// Load database
		$this->load->model('Auth_Model'); //Model of which contain all the database activity
		
		// Load email
		$this->load->helper('email');

		//load date 
		$this->load->helper('date');
	}


	public function new_user_registration() {
		$HashKey=md5(mt_rand());
		$date = date('Y-m-d H:i:s');
		$data = array(
		'FirstName' => $this->input->post('FirstName'),
		'LastName' => $this->input->post('LastName'),
		'PhoneNumber' => $this->input->post('PhoneNumber'),
		'EmailId' => $this->input->post('EmailId'),
		'PassWord' => md5($this->input->post('Password')),
		'ActiveLevel' => 0,
		'HashKey' =>$HashKey,
		'CreateUserId' => $this->input->post('EmailId'),
		'CreateDate' => $date
		);
		$result = $this->Auth_Model->registration_insert($data);
			if ($result == TRUE) {
			
			//code for email  
				$data = '<div class="alert alert-success"><p>Registration Successfully and verification email has been send to email!</p></div>';
				$this->session->set_flashdata('message',$data);
				$email= $this->input->post('EmailId');
				$hash=$HashKey;
				$sendmail = array(
					'EmailId' => $email,
					'HashKey' => $hash,
					'flag' => 1
					);
				$this->create_email($sendmail);
				
					redirect('Home/auth');	
				
			} else {
				$data = '<div class="alert alert-danger"><p>email id is already register</p></div>';
				$this->session->set_flashdata('message',$data); 
				redirect('Home/auth');
				}
		}//end of the new_user_registration function
	
		



		public function user_login_process() {
			
			$this->form_validation->set_rules('EmailId','EmailId','required|trim|valid_email');
			$this->form_validation->set_rules('Password','Password','required');

			$this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
				if($this->form_validation->run()){
					//successs
					//echo "validation successfully";
					$EmailId = $this->input->post('EmailId');
					$Password = $this->input->post('Password');
					$login_id = $this->Auth_Model->login_valid($EmailId,$Password);
					if($login_id){
						//successful
						//echo "Password match";
						$this->session->set_userdata('id',$login_id);
						return redirect('Test/dashboard');
					} else {
						$data = "<p class='test-danger'>Username & Password Doent Match</p>";
						$this->session->set_flashdata('login_failed',$data);
						return redirect('Home/auth');
					} 
				}else{
					$this->load->view('header');
					$this->load->view('signup');
					$this->load->view('footer');
				}
		}

	//end of the class

	
		// Logout from admin page
		public function logout() {

		// Removing session data
			//$sess_array = array('username' => '');
			$this->session->unset_userdata('id');
			$data['message_display'] = 'Successfully Logout';
			return redirect('Home/auth');
	}



	public function create_email($sendmail){
		if($sendmail['flag']==1){
			$url=site_url('Verify/email_verify/'.$sendmail['HashKey']);	
		}
		else{

			$url="http://localhost/dev.propchunk.com/verify/forget_password/".$sendmail['HashKey'];
		}
		$this->load->library('email');
      	$this->email->set_newline("\r\n");
      	$this->email->from('hello@propchunk.com'); // change it to yours
      	$this->email->to($sendmail['EmailId']);// change it to yours

		$this->email->subject('Activate Your Account');
		$this->email->message($url);
      	$this->email->send();
		
	}

}


?>