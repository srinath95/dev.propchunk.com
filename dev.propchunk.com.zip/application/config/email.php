<?php 
$config['protocol']  = 'smtp';
$config['smtp_host'] = 'propchunk.com';
$config['smtp_port'] = 25;
$config['smtp_user'] = 'contact@propchunk.com'; // change it to yours
$config['smtp_pass'] = 'Cr0wdFund1ng'; // change it to yours
$config['mailtype']  = 'html';
$config['charset']    = 'iso-8859-1';
$config['wordwrap'] = TRUE;
?>