
		<div class="container">
	    
    <div class="row col-lg-3 " style="margin-top:31px;">
         <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" /></div>
                        
        </div>

    <div class="row col-lg-2 " style="margin-top:31px;" >
                            <div class style="float:right;">
                        <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" >
                            Subscribe</button>
                    </div></div>
	<div class="row col-lg-2 ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
	


    	<div class="col-lg-5 ">
			<div class="widget-contact">
	
                <address>
                  <strong>We're on social networks</strong><br>
                        <ul class="company-social">
                            <li class="social-facebook"><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-twitter"><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        </ul>   
                </address>                  

                <h5>Main Office</h5>
				<address>
				  D/9, Ansa Estate,<br>
				  Opp. Kotak Bank & Vodafone Gallery,<br>
				  Saki Naka, Andheri (E), Mumbai.<br>
				  <abbr>P:</abbr> +91 9699 796629

				</address>

				<address>
				  <strong>Email</strong><br>
				  <a href="mailto:#"> hello@propchunk.com</a>
				</address>	
				<address>

                <address>
                  <strong>2016. All Rights Reserved.<br />
    
    Chunk Technologies Pvt. Ltd.</strong>
                 
                </address>  	
			 
                
			</div>	
		</div>
    </div>	

		</div>
	</section>
	<!-- /Section: contact -->

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>

