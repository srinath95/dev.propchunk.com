<?php
include('header.php');

include('x.php');
include('footer.php');

?>